using Robust.Shared.GameObjects;

namespace Content.Server.RBMK;

[RegisterComponent]
public sealed partial class RBMKFuelRodComponent : Component
{
    public float Resource = 100f;
    public float Temperature = 20f;
    public float XenonPoison = 0f;
}