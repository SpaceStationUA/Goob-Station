using Robust.Shared.GameObjects;

namespace Content.Server.RBMK;

public sealed class RBMKSystem : EntitySystem
{
    public override void Update(float frameTime)
    {
        var fuels = EntityQueryEnumerator<RBMKFuelRodComponent, RBMKColumnComponent>();

        while (fuels.MoveNext(out var uid, out var rod, out var column))
        {
            if (column.NeutronFlux > 10)
            {
                rod.Temperature += column.NeutronFlux * 0.5f;
                column.Heat += column.NeutronFlux * 2f;
                rod.Resource -= 0.01f;
            }

            if (rod.Temperature > 13000)
            {
                column.Heat += 5000;
            }

            if (column.NeutronFlux < 10 && rod.Temperature < 1000)
            {
                rod.XenonPoison += 1f * frameTime;
            }
        }
    }
}