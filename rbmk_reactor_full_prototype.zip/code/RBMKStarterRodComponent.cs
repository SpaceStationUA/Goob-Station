using Robust.Shared.GameObjects;

namespace Content.Server.RBMK;

[RegisterComponent]
public sealed partial class RBMKStarterRodComponent : Component
{
    public float NeutronBurst = 50f;
}