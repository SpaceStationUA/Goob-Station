using Robust.Shared.GameObjects;

namespace Content.Server.RBMK;

[RegisterComponent]
public sealed partial class RBMKColumnComponent : Component
{
    public float Heat = 0f;
    public float NeutronFlux = 0f;
}